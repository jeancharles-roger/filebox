/*****************************************************************************/
/***  (c) 2002-2007, DevWizard (DevWizard@free.fr)                         ***/
/***                                                                       ***/
/***                                                                       ***/
/***   Example 5                                                           ***/
/***                                                                       ***/
/*****************************************************************************/

package com.devwizard.javaexe.examples.example5;


import com.devwizard.javaexe.examples.common.service.*;


/*****************************************************************************/
public class Example5 extends Examples_AppService
{
	/*******************************************/
	public static void main(String[] args)
	{
		Example5_ServiceManagement.serviceInit();
	}
}
