/*****************************************************************************/
/***  (c) 2002-2007, DevWizard (DevWizard@free.fr)                         ***/
/***                                                                       ***/
/***                                                                       ***/
/***   Example 6                                                           ***/
/***                                                                       ***/
/*****************************************************************************/

package com.devwizard.javaexe.examples.example6;


import com.devwizard.javaexe.examples.common.*;


/*****************************************************************************/
public class Example6_Config extends Examples_Config
{
	/*******************************************/
	public static void init()
	{
		init("Example6");
	}
}
