/*****************************************************************************/
/***  (c) 2002-2007, DevWizard (DevWizard@free.fr)                         ***/
/*****************************************************************************/

package com.devwizard.javaexe.interfaces;


/*****************************************************************************/
public interface JavaExe_I_ApplicationManagement
{
	// public static boolean isCloseSplash();
	// public static boolean isOneInstance(String[] args);
}
