/*****************************************************************************/
/***  (c) 2002-2007, DevWizard (DevWizard@free.fr)                         ***/
/*****************************************************************************/

package com.devwizard.javaexe.examples.common;


import javax.swing.*;


/*****************************************************************************/
public class Examples_Frame extends JFrame
{
	/*******************************************/
	public Examples_Frame(String title)
	{
		super(title);

		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}
}
