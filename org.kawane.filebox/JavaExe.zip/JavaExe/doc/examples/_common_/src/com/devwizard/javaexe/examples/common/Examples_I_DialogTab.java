/*****************************************************************************/
/***  (c) 2002-2007, DevWizard (DevWizard@free.fr)                         ***/
/*****************************************************************************/

package com.devwizard.javaexe.examples.common;


import java.util.*;


/*****************************************************************************/
public interface Examples_I_DialogTab
{
	public void loadProperties(Properties prop);
	public void saveProperties(Properties prop);
}
