/*****************************************************************************/
/***  (c) 2002-2007, DevWizard (DevWizard@free.fr)                         ***/
/***                                                                       ***/
/***                                                                       ***/
/***   Example 2                                                           ***/
/***                                                                       ***/
/*****************************************************************************/

package com.devwizard.javaexe.examples.example2;


import java.awt.*;
import javax.swing.*;
import com.devwizard.javaexe.examples.common.*;


/*****************************************************************************/
public class Example2_DialogTab3 extends JPanel
{
	/*******************************************/
	public Example2_DialogTab3()
	{
		super(new BorderLayout());

		add("Center", new JLabel(Examples_UtilsGUI.getIcon("construct.gif")));
	}
}
