/*****************************************************************************/
/***  (c) 2002-2007, DevWizard (DevWizard@free.fr)                         ***/
/***                                                                       ***/
/***                                                                       ***/
/***   Example 1                                                           ***/
/***                                                                       ***/
/*****************************************************************************/

package com.devwizard.javaexe.examples.example1;


import com.devwizard.javaexe.examples.common.*;


/*****************************************************************************/
public class Example1_Config extends Examples_Config
{
	/*******************************************/
	public static void init()
	{
		init("Example1");
	}
}
